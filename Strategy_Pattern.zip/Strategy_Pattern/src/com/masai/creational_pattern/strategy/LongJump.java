package com.masai.creational_pattern.strategy;

public class LongJump implements JumpBehaviour{
    @Override
    public void jump() {

    }
}
