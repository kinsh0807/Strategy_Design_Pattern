package com.masai.creational_pattern.strategy;

public class LighteningKick implements KickBehaviour {

    @Override
    public void kick() {

    }
}
