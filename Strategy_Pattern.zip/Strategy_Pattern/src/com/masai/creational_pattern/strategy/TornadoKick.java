package com.masai.creational_pattern.strategy;

public class TornadoKick implements KickBehaviour{
    @Override
    public void kick() {

    }
}
