package com.masai.creational_pattern.strategy;

public interface KickBehaviour {

    public void kick();
}
