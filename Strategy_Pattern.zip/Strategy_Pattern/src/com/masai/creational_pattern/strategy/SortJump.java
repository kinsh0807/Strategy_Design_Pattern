package com.masai.creational_pattern.strategy;

public class SortJump implements JumpBehaviour{
    @Override
    public void jump() {

    }
}
