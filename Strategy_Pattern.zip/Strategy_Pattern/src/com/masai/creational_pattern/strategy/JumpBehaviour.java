package com.masai.creational_pattern.strategy;

public interface JumpBehaviour {

     void jump();
}
